Chapter 3 - Names for Numbers
::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   assignName.rst
   expression.rst
   expressionTable.rst
   orderOfOperations.rst
   driving.rst
   ketchup.rst
   walkAssign.rst
   invoice.rst
   ch3_summary.rst
   ch3_exercises.rst
   VariablePracticeParsons.rst
