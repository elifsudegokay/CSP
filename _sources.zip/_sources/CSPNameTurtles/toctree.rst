Chapter 5 - Names for Turtles
::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   names4turtles.rst
   FuncAndProc.rst
   TurtlePractice.rst
   turtleFAP.rst
   multTurtles.rst
   house.rst
   changeProg.rst
   ch5_summary.rst
   ch5_exercises.rst