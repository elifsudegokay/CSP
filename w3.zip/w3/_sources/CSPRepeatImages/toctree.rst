Chapter 11 - Repeating Steps with Images
:::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   repeatimages.rst
   imageAbstractions.rst
   pattern.rst
   changeColor.rst
   changeColorLoc.rst
   changeData.rst
   ch11_summary.rst
   ch11_exercises.rst
   exam9t11.rst