3. Bölüm ~ Bilgisayarlar Karar Verebilir
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   decisions.rst
   if.rst
   multiple.rst
   logicalEx.rst
   complex.rst
   practice.rst
   ifAndElse.rst
   elif.rst
   ch12_summary.rst
   ch12_exercises.rst
