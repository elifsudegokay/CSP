Chapter 9 - Repeating Steps with Strings
:::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   repeatstrings.rst
   reverse.rst
   mirror.rst
   modify.rst
   ch9_summary.rst
   ch9_exercises.rst