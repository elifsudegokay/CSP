Chapter 13 - Using Decisions with Strings
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   decisionStrings.rst
   input.rst
   fortuneTeller.rst
   elif.rst
   ch13_summary.rst
   ch13_exercises.rst
   exam12a13.rst
