2. Ünite - Bilgisayarlar Ne Yapabilir ?
::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   whatIsComputer.rst
   turingMachines.rst
   abilities.rst
   ch2_summary.rst
   exam1a2.rst
