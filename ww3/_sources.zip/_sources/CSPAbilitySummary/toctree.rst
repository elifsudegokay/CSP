Chapter 19 - Computer Abilities Summary
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   thatsall.rst
   ch19_summary.rst
   examPost.rst
