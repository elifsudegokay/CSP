Chapter 10 - Repeating Steps with Turtles
::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   repeatturtles.rst
   turtleGeom.rst
   patterns.rst
   stamp.rst
   RepeatTurtlesPractice.rst
   ch10_summary.rst
   ch10_exercises.rst