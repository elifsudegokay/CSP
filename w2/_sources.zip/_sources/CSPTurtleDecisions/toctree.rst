Chapter 14 - Using Decisions with Turtles
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   turtleFP.rst
   decTurtle.rst
   oddEven.rst
   random.rst
   collisions.rst
   ch14_summary.rst
   ch14_exercises.rst