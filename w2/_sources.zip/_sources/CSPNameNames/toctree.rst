Chapter 6 - Computers can Name Anything
:::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   names4names2.rst
   nameFandP.rst
   nameSteps.rst
   namesInput.rst
   nameSets.rst
   imageLib.rst
   renameFunctions.rst
   ch6_summary.rst
   ch6_exercises.rst
   exam5a6.rst