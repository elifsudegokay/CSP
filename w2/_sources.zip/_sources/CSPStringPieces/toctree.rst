Chapter 17 - Getting pieces out of strings and lists
:::::::::::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   piecesstrings.rst
   madLibPieces.rst
   split.rst
   outOfRange.rst
   strProcParam.rst
   createPartsOfStrings.rst
   ch17_summary.rst
   ch17_exercises.rst
   exam16a17.rst