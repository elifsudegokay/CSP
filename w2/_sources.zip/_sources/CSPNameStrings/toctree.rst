Chapter 4 - Names for Strings
::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   assignNameStr.rst
   strObjects.rst
   immutable.rst
   madlib.rst
   ch4_summary.rst
   ch4_exercises.rst
   exam3a4.rst