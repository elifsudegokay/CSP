Chapter 12 - A Computer can Make Decisions
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   decisions.rst
   if.rst
   multiple.rst
   logicalEx.rst
   complex.rst
   practice.rst
   ifAndElse.rst
   ch12_summary.rst
   ch12_exercises.rst