Chapter 7 - Computers can Repeat Steps
:::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   repeatSteps.rst
   repeatNums.rst
   list.rst
   range.rst
   accumPattern.rst
   print.rst
   ch7_summary.rst
   ch7_exercises.rst